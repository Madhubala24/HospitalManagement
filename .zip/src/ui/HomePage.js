import React from "react";
import { Link, useNavigate } from "react-router-dom";

 function HomePage() {
  const navigate=useNavigate();
  const handleLogout = () => {
    // Clear logged-in status and details
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("loggedInDoctor");
    // Redirect to the login page
    navigate("/");
  };
  
  return (
    <div>
      <button onClick={handleLogout}> Logout </button>
      <h1>Welcome to the Hospital Management System</h1>
      <p>Choose an option:</p>
      <div className="buttons">
        <Link to="/doctor-management">
          <button>Doctor Management</button>
        </Link>
        <Link to="/appointment-management">
          <button>Appointment Booking</button>
        </Link>
        <Link to="/appointment-details">
          <button>Appointment Details</button>
        </Link>
      </div>
    </div>
  );
}
export default HomePage;