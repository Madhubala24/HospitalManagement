// LoginData.js
const doctorData = [
  {
    doctorusername: "Warner",
    password: "Welcome",
  },
  {
    doctorusername: "smith",
    password: "Welcome",
  },
  {
    doctorusername: "anderson",
    password: "Welcome",
  },
  {
    doctorusername: "wilson",
    password: "Welcome",
  },
  {
    doctorusername: "jones",
    password: "Welcome",
  },
];

const patientData = [
  {
    username: "Ramya",
    password: "123456",
  },
  {
    username: "Parvatha",
    password: "123456",
  },
];

export { doctorData, patientData };
